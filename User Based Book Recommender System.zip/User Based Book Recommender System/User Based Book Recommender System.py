#!/usr/bin/env python
# coding: utf-8

# In[159]:


# In[5]:


get_ipython().system('pip install country_converter')


# In[135]:


import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import country_converter as coco

import seaborn as sns

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from plotly.offline import iplot
from PIL import Image
import requests
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

import warnings
warnings.filterwarnings('ignore')


# In[136]:


pip install missingno


# In[137]:


books = pd.read_csv('Books.csv')
ratings = pd.read_csv('ratings.csv')
users = pd.read_csv('users.csv')


# In[138]:


books['Image-URL-M'][1]


# # Data Preprocessing

# In[139]:


books.isnull().sum()


# In[140]:


users.isnull().sum()


# In[141]:


books.duplicated().sum()


# In[142]:


users.duplicated().sum()


# In[143]:


#user item matrix creating
ratings_with_name = ratings.merge(books,on='ISBN')


# In[145]:


num_rating_df = ratings_with_name.groupby('Book-Title').count()['Book-Rating'].reset_index()
num_rating_df.rename(columns={'Book-Rating':'num_ratings'},inplace=True)


# In[146]:


avg_rating_df = ratings_with_name.groupby('Book-Title').mean()['Book-Rating'].reset_index()
avg_rating_df.rename(columns={'Book-Rating':'avg_rating'},inplace=True)


# In[147]:


popular_df = num_rating_df.merge(avg_rating_df,on='Book-Title')


# In[152]:


x = ratings_with_name.groupby('User-ID').count()['Book-Rating'] > 200
padhe_likhe_users = x[x].index


# In[153]:


filtered_rating = ratings_with_name[ratings_with_name['User-ID'].isin(padhe_likhe_users)]


# In[154]:


y = filtered_rating.groupby('Book-Title').count()['Book-Rating']>=50
famous_books = y[y].index


# In[155]:


final_ratings = filtered_rating[filtered_rating['Book-Title'].isin(famous_books)]


# In[156]:


pt = final_ratings.pivot_table(index='Book-Title',columns='User-ID',values='Book-Rating')


# In[157]:


pt.fillna(0,inplace=True)


# In[158]:


pt


# # Exploratory Data Analysis

# In[10]:


print(books.head(5))


# In[11]:


print(ratings.head(6))


# In[12]:


print(users.head(6))


# In[13]:


def shape_of_dataset(df, dataset_name="df"):
    
    print(f"{dataset_name} dataset has {df.shape[0]} nrows and {df.shape[1]} ncolumns")
    return df.shape[0], df.shape[1]


# In[14]:


books_r, books_c = shape_of_dataset(books, "Books")
ratings_r, ratings_c = shape_of_dataset(ratings, "Ratings")
users_r, users_c = shape_of_dataset(users, "Users")


# In[15]:


def count_null_values(df, dataset_name):
    
    num_of_total_null_values = sum(df.isnull().sum().values)
    print(f"{dataset_name} dataset has {num_of_total_null_values} null values")
    return num_of_total_null_values


# In[16]:


books_null = count_null_values(books, "Books")
ratings_null = count_null_values(ratings, "Ratings")
users_null = count_null_values(users, "Users")


# In[17]:


def detect_null_columns(df, dataset_name):
    
    col = []
    s = df.isnull().sum()
    for x in range(len(s)):
        if s[x] > 0:
            col.append(s.index[x])
    tot_cols = len(col)
    if tot_cols == 0:
        print(f"{dataset_name} dataset has no null columns")
        print("="*50)
    else:
        print(f"{dataset_name} dataset has {tot_cols} null columns and they are:")
        for x in col:
            print(x, end=',')
        print()
        print("="*50)
    return col, len(col)


# In[18]:


total_books_null_cols, books_null_cols = detect_null_columns(books, "Books")
total_ratings_null_cols, ratings_null_cols = detect_null_columns(ratings, "Ratings")
total_users_null_cols, users_null_cols = detect_null_columns(users, "Users")


# In[19]:


detailed_db = pd.DataFrame({
    'dataset' : [],
    'nrows' : [],
    'ncols' :[],
    'null_amount' : [],
    'names_of_null_cols' : [],
    'num_null_cols' : []
})


# In[20]:


def fill_db_dataset(dataset_name, nrows, ncols, null_amount, name_null_cols, num_null_cols):
    detailed_db.loc[len(detailed_db.index)] = [dataset_name, nrows, ncols, null_amount, ', '.join(name_null_cols), int(num_null_cols)]


# In[21]:


fill_db_dataset('Books', books_r, books_c, books_null, total_books_null_cols, books_null_cols)
fill_db_dataset('Ratings', ratings_r, ratings_c, ratings_null, total_ratings_null_cols, ratings_null_cols)
fill_db_dataset('Users', users_r, users_c, users_null, total_users_null_cols, users_null_cols)


# In[22]:


detailed_db


# In[23]:


def print_info_about_ds(df, name_of_the_ds = "df"):
    print(f"Info about the {name_of_the_ds} dataset: ")
    dash_sep()
    print(df.info())
    
def dash_sep(num=50):
    print("_"*num)

def double_fs_sep(num=40):
    print("//"*num)


# In[24]:


print_info_about_ds(books, "Books")
double_fs_sep()

print_info_about_ds(ratings, "Ratings")
double_fs_sep()

print_info_about_ds(users, "Users")


# In[25]:


def print_nunique_vals(df, ds_name = 'df'):
    print(f"number of unique values in each column in the {ds_name} dataset:")
    dash_sep(75)
    print(df.nunique())


# In[26]:


print_nunique_vals(books, 'Books')
double_fs_sep()

print_nunique_vals(ratings, 'Ratings')
double_fs_sep()

print_nunique_vals(users, 'Users')


# In[27]:


def plot_miss_vals(df, ds_name):
    msno.matrix(df)
    plt.title(f'Distribution of Missing Values in {ds_name} dataset', fontsize=30, fontstyle='oblique')
    plt.show()


# In[28]:


import missingno as msno


# In[29]:


plot_miss_vals(books, "Books")
plot_miss_vals(ratings, "Ratings")
plot_miss_vals(users, "Users")


# In[30]:


def print_dtype_of_df(df, ds_name = 'df'):
    print(f"data type of each column in the {ds_name} dataset:")
    dash_sep(75)
    print(df.dtypes)


# In[31]:


print_dtype_of_df(books, 'Books')
double_fs_sep()

print_dtype_of_df(ratings, 'Ratings')
double_fs_sep()

print_dtype_of_df(users, 'Users')


# In[32]:


def plot_top20(df, column, title, x_label, y_label, top=20, template = 'plotly_dark'):
    
    pl = df[column].value_counts().head(top)
    fig = px.bar(y=pl.values, 
                 x=pl.index, 
                 color_discrete_sequence=px.colors.sequential.PuBuGn,
                 text=pl.values,
                 title= title,
                 template= template)
    fig.update_layout(
        xaxis_title=x_label,
        yaxis_title=y_label,
        font = dict(size=15,family="Franklin Gothic"))
    fig.show()


# In[34]:


books[(books['Year-Of-Publication'] == 'DK Publishing Inc') | (books['Year-Of-Publication'] == 'Gallimard')]


# In[35]:


temp = books[(books['Year-Of-Publication'] == 'DK Publishing Inc') | (books['Year-Of-Publication'] == 'Gallimard')]


# In[36]:


temp[temp['Book-Author'] == temp['Book-Author'][209538]]['Book-Title'].values[1]
'''As we can see here in the previous outputs that the name of the authors are concatenated with the Book title 
so we need to seperate them
-Preprocessing.'''


# In[37]:


authors = []
books_titles = []

for title in temp['Book-Title']:
    
    author = title.split(';')[-1].split('"')[0]
    book = title.split(';')[0].split('\\')[0]

    authors.append(author)
    books_titles.append(book)


# In[38]:


authors


# In[39]:


books_titles


# In[40]:


'''now we have separated the book titles and the authors lets shift the values and assign the new ones'''
cols_to_shift = books.columns[1:]
cols_to_shift


# In[41]:


temp = pd.concat([temp['ISBN'].to_frame(), temp[cols_to_shift].shift(periods = 1, axis = 1)], axis=1)
temp


# In[42]:


temp['Book-Title'] = books_titles
temp['Book-Author'] = authors
#preprocessing


# In[43]:


temp


# In[44]:


rows_to_rem = list(temp.index)
rows_to_rem


# In[45]:


books.shape


# In[46]:


for ind in rows_to_rem:
    
    books.loc[ind] = list(temp.loc[ind].values)


# In[47]:


books['Year-Of-Publication'] = books['Year-Of-Publication'].astype('int32')


# In[48]:


books.dtypes


# In[49]:


plot_top20(books, 'Year-Of-Publication', 'Top 20 years in which books were published in terms of count', "Year", "Count")


# In[50]:


year_count=books['Year-Of-Publication'].value_counts()
year_count=pd.DataFrame(year_count)

plt.figure(figsize=(10, 9))
sns.lineplot(data=year_count)
plt.title('Year of Publication count (1950 - 2010)')
plt.xlim(1950, 2011)
plt.xlabel('Year')
plt.ylabel('Total Books Published')
plt.show()


# In[51]:


plot_top20(books, 'Book-Author', "Top 20 Authors authored books by count", "Author name", "Count")


# In[52]:


plot_top20(books, 'Publisher', "Top 20 Publishers who have published books", "Publisher name", "Count")


# In[53]:


#Feature extractipn
countries = []
cond = users['Location'].str.split(',')

for cont in cond:
    
    countries.append(cont[-1])


# In[54]:


#extracted the countries, let's assign the countries to the dataset
users['Country'] = countries
users.head()


# In[55]:


books_with_ratings = pd.merge(books, ratings, on='ISBN')#merging


# In[56]:


books_with_ratings.head()


# In[57]:


def cat_summary_with_graph(dataframe, col_name):
    fig = make_subplots(rows=1, cols=2,
                        subplot_titles=('Countplot', 'Percentages'),
                        specs=[[{"type": "xy"}, {'type': 'domain'}]])

    fig.add_trace(go.Bar(y=dataframe[col_name].value_counts().values.tolist(),
                         x=[str(i) for i in dataframe[col_name].value_counts().index],
                         text=dataframe[col_name].value_counts().values.tolist(),
                         textfont=dict(size=15),
                         name=col_name,
                         textposition='auto',
                         showlegend=False,
                         marker=dict(color=colors,
                                     line=dict(color='#DBE6EC',
                                               width=1))),
                  row=1, col=1)

    fig.add_trace(go.Pie(labels=dataframe[col_name].value_counts().keys(),
                         values=dataframe[col_name].value_counts().values,
                         textfont=dict(size=10),
                         textposition='auto',
                         showlegend=False,
                         name=col_name,
                         marker=dict(colors=colors)),
                  row=1, col=2)

    fig.update_layout(title={'text': col_name,
                             'y': 0.9,
                             'x': 0.5,
                             'xanchor': 'center',
                             'yanchor': 'top'},
                      template='plotly_white')

    iplot(fig)


# In[58]:


colors = ['#494BD3', '#E28AE2', '#F1F481', '#79DB80', '#DF5F5F',
              '#69DADE', '#C2E37D', '#E26580', '#D39F49', '#B96FE3']


# In[59]:


cat_summary_with_graph(books_with_ratings, 'Book-Rating')


# In[60]:


'''Now let's see the average rating of the books of the top 20 authors
First we are returning the top 20 authors in the data'''
authors_top20 = books['Book-Author'].value_counts().head(20)
authors_top20 = list(authors_top20.index)


# In[61]:


books_with_ratings.dropna(inplace=True)


# In[62]:


top20_authors = pd.DataFrame(columns = books_with_ratings.columns)

for author in authors_top20:
    
    cond_df = books_with_ratings[books_with_ratings['Book-Author'] == author]
    
    top20_authors =  pd.concat([top20_authors, cond_df], axis=0)


# In[63]:


#we have returned the top 20 authors succssefully!! so the top20_authors df contains only 20 authors
top20_authors.shape


# In[64]:


#preprovessing
'''There is no 0 rating, ratings is from 1-10 scale, then 0 means the book is not rated that it is not rated 
so we are excluding the zero rating from our data'''
top20_author = top20_authors[top20_authors['Book-Rating'] != 0]


# In[65]:


top20_author.shape


# In[66]:


#EDA-Mean of authors
top20_author = top20_author.groupby('Book-Author')['Book-Rating'].agg('mean').reset_index().sort_values(by='Book-Rating', ascending=False)
top20_author


# In[67]:


fig = px.bar(y=top20_author['Book-Rating'], 
             x=top20_author['Book-Author'], 
             color_discrete_sequence=px.colors.sequential.PuBuGn,
             text=round(top20_author['Book-Rating'],2),
             title= "Average ratings of the books of the Top 20 authors",
             template= 'plotly_dark')
fig.update_layout(
    xaxis_title="author name",
    yaxis_title="average rating",
    font = dict(size=15,family="Franklin Gothic"))
fig.show()


# In[68]:


publishers_top20 = books['Publisher'].value_counts().head(20)
publishers_top20 = list(publishers_top20.index)

top20_publishers = pd.DataFrame(columns = books_with_ratings.columns)

for pub in publishers_top20:
    
    cond_df = books_with_ratings[books_with_ratings['Publisher'] == pub]
    
    top20_publishers =  pd.concat([top20_publishers, cond_df], axis=0)
    
    
top20_publishers = top20_publishers[top20_publishers['Book-Rating'] != 0]
top20_publishers = top20_publishers.groupby('Publisher')['Book-Rating'].agg('mean').reset_index().sort_values(by='Book-Rating', ascending=False)

top20_publishers


# In[69]:


fig = px.bar(y=top20_publishers['Book-Rating'], 
             x=top20_publishers['Publisher'], 
             color_discrete_sequence=px.colors.sequential.PuBuGn,
             text=round(top20_publishers['Book-Rating'],2),
             title= "Average ratings of the books of the Top 20 Publishers",
             template= 'plotly_dark')
fig.update_layout(
    xaxis_title="Publisher name",
    yaxis_title="average rating",
    font = dict(size=15,family="Franklin Gothic"))
fig.show()


# In[70]:


df = pd.merge(books_with_ratings, users, on='User-ID')
df = books_with_ratings[books_with_ratings['Book-Rating'] != 0]
plot_top20(df, 'Book-Title', "Most Rated Books by Users", "Book Title", "Number of ratings")


# In[71]:


books_top20 = df['Book-Title'].value_counts().head(20)
books_top20 = list(books_top20.index)

top20_books = pd.DataFrame(columns = books_with_ratings.columns)

for book in books_top20:
    
    cond_df = books_with_ratings[books_with_ratings['Book-Title'] == book]
    
    top20_books =  pd.concat([top20_books, cond_df], axis=0)
    
    
top20_books = top20_books[top20_books['Book-Rating'] != 0]
top20_books = top20_books.groupby('Book-Title')['Book-Rating'].agg('mean').reset_index().sort_values(by='Book-Rating', ascending=False)

top10_books = top20_books.head(10)
top10_books


# In[72]:


fig = px.bar(y=top10_books['Book-Rating'], 
             x=top10_books['Book-Title'], 
             color_discrete_sequence=px.colors.sequential.PuBuGn,
             text=round(top10_books['Book-Rating'],2),
             title= "Top 10 rated books by the users",
             template= 'plotly_dark')
fig.update_layout(
    xaxis_title="Book title",
    yaxis_title="average rating",
    font = dict(size=15,family="Franklin Gothic"))
fig.show()


# In[73]:


#FEATURE SELECTION


# In[77]:


df.head(5)


# In[78]:


df.shape


# #  Most Popular Books recommendation

# In[79]:


def prGreen(skk): print("\033[92m {}\033[00m" .format(skk))
def prRed(skk): print("\033[91m {}\033[00m" .format(skk))
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk))

    
def popular_books():
    
    for (book, ratings) in zip(top10_books['Book-Title'], top10_books['Book-Rating']):
        prGreen(book)
        print("Rating",end='->')
        prRed(round(ratings,1))
        print("-"*50)
        
popular_books()


# # Based Collaborative Filtering

#  Item Based Collaborative Filtering

# In[81]:


count_rate = pd.DataFrame(df['Book-Title'].value_counts())
count_rate.head(20)


# In[82]:


#So we are going to classify the rare books as the books who got rated 100 or less times
rare_books=count_rate[count_rate["Book-Title"]<=100].index
rare_books[:5]


# In[83]:


len(rare_books)


# In[84]:


#so if the book is not included in the rare books we are going to classify it as common one
common_books=df[~df["Book-Title"].isin(rare_books)]
common_books.head()


# In[85]:


common_books.shape


# In[86]:


'''Now lets make recommendation if the book is common
First lets create dataframe which its index is the Users IDs and the columns are the books titles,
and the values are the rating of the user to that book'''
item_based_cb = common_books.pivot_table(index=["User-ID"],columns=["Book-Title"],values="Book-Rating")


# In[90]:


#Now we are creating recommendation df with the corrwith function
book_title = 'Me Talk Pretty One Day'
sim = item_based_cb[book_title]
recommendation_df=pd.DataFrame(item_based_cb.corrwith(sim).sort_values(ascending=False)).reset_index(drop=False)
recommendation_df


# In[91]:


'''Lets check if the book the user choosen is included in the recommendation df or not, because
if it is included we don't want to recommend it so we will make sure to drop it'''
if not recommendation_df['Book-Title'][recommendation_df['Book-Title'] == book_title].empty:
    recommendation_df=recommendation_df.drop(recommendation_df[recommendation_df["Book-Title"]==book_title].index[0])


# In[92]:


#Lets now collect the books with less ratings (which its average rating is less than 5)
less_rating=[]
for i in recommendation_df["Book-Title"]:
    if df[df["Book-Title"]==i]["Book-Rating"].mean() < 5:
        less_rating.append(i)
        
less_rating


# In[93]:


#Lets make sure to rank the highly rated books
if recommendation_df.shape[0] - len(less_rating) > 5:
    
    recommendation_df=recommendation_df[~recommendation_df["Book-Title"].isin(less_rating)]            
    recommendation_df.columns=["Book-Title","Correlation"]
    
    
for (candidate_book, corr) in zip(recommendation_df['Book-Title'], recommendation_df['Correlation']):
    corr_thershold = 0.7
    if corr > corr_thershold:
        ratings = df[df['Book-Title'] == candidate_book]['Book-Rating'].mean()
        prGreen(candidate_book)
        print("Rating ", end = '->')
        prRed(round(ratings,1))
        print("-"*50)
    else:
        break


# In[94]:


'''Hooray!! We created the recommendation system :)
Now our item based collaborative recommendation system is ready, lets put it all together to bulild our RS'''
def item_based_coll_rs(book_title):
    
    book_title = str(book_title)
    if book_title in books_with_ratings['Book-Title'].values:
        
        count_rate = pd.DataFrame(df['Book-Title'].value_counts())
        rare_books=count_rate[count_rate["Book-Title"]<=100].index
        
        common_books=df[~df["Book-Title"].isin(rare_books)]

        if book_title in rare_books:
            prYellow("A rare book, so u may try our popular books: \n ")
            popular_books()
            
        else:
            
            item_based_cb = common_books.pivot_table(index=["User-ID"],columns=["Book-Title"],values="Book-Rating")
            sim = item_based_cb[book_title]
            recommendation_df=pd.DataFrame(item_based_cb.corrwith(sim).sort_values(ascending=False)).reset_index(drop=False)

            if not recommendation_df['Book-Title'][recommendation_df['Book-Title'] == book_title].empty:
                recommendation_df=recommendation_df.drop(recommendation_df[recommendation_df["Book-Title"]==book_title].index[0])

            less_rating=[]
            for i in recommendation_df["Book-Title"]:
                if df[df["Book-Title"]==i]["Book-Rating"].mean() < 5:
                    less_rating.append(i)

            if recommendation_df.shape[0] - len(less_rating) > 5:

                recommendation_df=recommendation_df[~recommendation_df["Book-Title"].isin(less_rating)]            
                recommendation_df.columns=["Book-Title","Correlation"]


            for (candidate_book, corr) in zip(recommendation_df['Book-Title'], recommendation_df['Correlation']):
                corr_thershold = 0.7
                if corr > corr_thershold:
                    ratings = df[df['Book-Title'] == candidate_book]['Book-Rating'].mean()
                    prGreen(candidate_book)
                    print("Rating ", end = '->')
                    prRed(round(ratings,1))
                    print("-"*50)
                else:
                    break
                
    else:
        prYellow("This book is not in our library, check out our most popular books:")
        print()
        popular_books()


# In[95]:


item_based_coll_rs('Me Talk Pretty One Day')


# In[98]:


item_based_coll_rs("RAMAYANA")


# In[99]:


item_based_coll_rs("Harry Potter and the Prisoner of Azkaban (Book 3)")


# In[100]:


item_based_coll_rs("From One to One Hundred")


# In[101]:


item_based_coll_rs("Tuesdays with Morrie An Old Man a Young Man and Life s Greatest Lesson")


# User Based Collaborative Filtering

# In[102]:


#First we return the active users who have presented in the dataset more than 100 times
new_df=df[df['User-ID'].map(df['User-ID'].value_counts()) > 100]


# In[103]:


new_df.shape


# In[104]:


#Lets make our matrix, User as indcies, Books as columns and finally ratings as values
users_matrix=new_df.pivot_table(index=["User-ID"],columns=["Book-Title"],values="Book-Rating")
users_matrix.head()


# In[105]:


#return user favorite books
user_id = 2033 # we assume we want to recommend for that user
users_fav=new_df[new_df["User-ID"]==user_id].sort_values(["Book-Rating"],ascending=False)[0:5]
users_fav.head()


# In[106]:


index=np.where(users_matrix.index==2033)[0][0]
index


# In[107]:


#Calculate the similarity between the active user and other users
users_matrix.fillna(0, inplace=True)


# In[108]:


#u should replace nan values with zero to calculate the similarity
similarity=cosine_similarity(users_matrix)
similarity[0]


# In[109]:


#getting users similar to the active user
similar_users = list(enumerate(similarity[index]))
similar_users[:5]


# In[110]:


#sort them of course users with high similarity will come first so we can recommend their interest to the active user
similar_users = sorted(similar_users,key = lambda x:x[1],reverse=True)[1:6]
similar_users


# In[115]:


#return the user Id for the similair users
user_rec=[]
    
for i in similar_users:
        data=df[df["User-ID"]==users_matrix.index[i[0]]]
        user_rec.extend(list(data.drop_duplicates("User-ID")["User-ID"].values))

user_rec


# In[116]:


x=new_df[new_df["User-ID"]==user_id]
recommend_books=[]
user=list(user_rec)
for i in user:
    y=new_df[(new_df["User-ID"]==i)]
    sim_books=y.loc[~y["Book-Title"].isin(x["Book-Title"]),:]
    sim_books=sim_books.sort_values(["Book-Rating"],ascending=False)[0:5]
    recommend_books.extend(sim_books["Book-Title"].values)
    
recommend_books


# In[117]:


#Now lets put it all together

new_df=df[df['User-ID'].map(df['User-ID'].value_counts()) > 100] 
users_matrix=new_df.pivot_table(index=["User-ID"],columns=["Book-Title"],values="Book-Rating")
users_matrix.fillna(0, inplace=True)


# In[123]:


def user_based_coll_rs(user_id):
    
    users_fav=new_df[new_df["User-ID"]==user_id].sort_values(["Book-Rating"],ascending=False)[0:5]
    
    prYellow("Your Top Favorite books: \n")

    for book in users_fav['Book-Title']:
        
        prGreen(book)
        print("Rating", end='->')
        prRed(round(df[df['Book-Title'] == book]['Book-Rating'].mean(), 2))
        print("-"*50)
        
    print("\n\n")
    
    index=np.where(users_matrix.index==2033)[0][0]
    
    similarity=cosine_similarity(users_matrix)
    similar_users = list(enumerate(similarity[index]))
    similar_users = sorted(similar_users,key = lambda x:x[1],reverse=True)[0:5]
    
    users_id=[]
    
    for i in similar_users:
        
            data=df[df["User-ID"]==users_matrix.index[i[0]]]
            users_id.extend(list(data.drop_duplicates("User-ID")["User-ID"].values))


    x=new_df[new_df["User-ID"]==user_id]
    recommend_books=[]
    user=list(users_id)
    
    for i in user:
        
        y=new_df[(new_df["User-ID"]==i)]
        sim_books=y.loc[~y["Book-Title"].isin(x["Book-Title"]),:]
        sim_books=sim_books.sort_values(["Book-Rating"],ascending=False)[0:5]
        recommend_books.extend(sim_books["Book-Title"].values)
    
    
    prYellow("Recommended for you: \n")
        
    for book in recommend_books:
        prGreen(book)
        print("Rating",end='->')
        prRed(round(df[df['Book-Title'] == book]['Book-Rating'].mean(),2))
        print("-"*50)


# In[124]:


user_based_coll_rs(2033)


# In[125]:


user_based_coll_rs(4385)


# In[160]:


#THANK YOU


# In[ ]:




